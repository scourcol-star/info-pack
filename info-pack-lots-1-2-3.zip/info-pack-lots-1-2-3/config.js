/* ============================================================
   TFB — Info Pack · configuration métier
   Tout ce qui se règle sans toucher au code de la fiche vit ici :
   formules de dimensions, paramètres du développé, unités.
   Chargé AVANT app.js (index.html) — pas de dépendance à app.js.
   ============================================================ */

/* ------------------------------------------------------------
   1 · Dimensions à plat, famille par famille
   mode : 'auto'   → calculé avec la formule nommée dans `formule`
          'manuel' → saisie à la main (aucune formule fiable)
          'na'     → non applicable, le champ est masqué
   Règle de sûreté : toute famille absente de cette table tombe en
   'manuel'. Une cote fausse envoyée à un imprimeur coûte une
   production entière — on ne devine pas une formule.
   ------------------------------------------------------------ */
const DIM_A_PLAT_PAR_FAMILLE = {
  'Sac':       { mode:'auto',   formule:'largeur_hauteur', note:'le sac tel qu’il est livré, aplati' },
  'Sachet':    { mode:'auto',   formule:'largeur_hauteur', note:'le sachet tel qu’il est livré, aplati' },
  'Papier':    { mode:'auto',   formule:'largeur_hauteur', note:'format déplié' },
  'Serviette': { mode:'auto',   formule:'largeur_hauteur', note:'format déplié' },
  'Étiquette': { mode:'auto',   formule:'largeur_hauteur', note:'format déplié' },
  'Boîte':     { mode:'manuel', note:'dépend du montage — se lit sur le gabarit fournisseur' },
  'Gobelet':   { mode:'na',     note:'produit non développable' },
  'Bouteille': { mode:'na',     note:'produit non développable' },
  'Bowl':      { mode:'na',     note:'produit non développable' },
  'Vaisselle': { mode:'na',     note:'produit non développable' },
  'Couvercle': { mode:'na',     note:'produit non développable' }
};
/* Accessoire, Bague, Couverts… : pas de formule connue → saisie manuelle. */
const DIM_A_PLAT_DEFAUT = { mode:'manuel', note:'aucune formule définie pour cette famille — saisie manuelle' };

/* Les formules elles-mêmes. `req` liste les dimensions nécessaires :
   si l'une manque, le champ affiche « — » plutôt qu'une valeur fausse. */
const A_PLAT_FORMULES = {
  largeur_hauteur: {
    lb:  'Largeur × Hauteur',
    req: ['largeur_cm', 'hauteur_cm'],
    calc: d => ({ l: d.largeur_cm, h: d.hauteur_cm })
  }
};

/* ------------------------------------------------------------
   2 · Développé (à découper) — la cote qui intéresse l'imprimeur
   (2 × Largeur + 2 × Soufflet + rabat) × (Hauteur + fond)
   rabat et fond sont deux paramètres modifiables par référence.
   ------------------------------------------------------------ */
const DEVELOPPE = {
  familles: ['Sac', 'Sachet', 'Boîte'],
  lb:  '(2 × Largeur + 2 × Soufflet + rabat) × (Hauteur + fond)',
  req: ['largeur_cm', 'profondeur_soufflet_cm', 'hauteur_cm'],
  rabat_defaut: 2,                                  // cm
  rabat_lb: '2 cm',
  fond_defaut: d => d.profondeur_soufflet_cm / 2 + 2, // cm
  fond_lb: 'soufflet ÷ 2 + 2 cm',
  calc: (d, rabat, fond) => ({
    l: 2 * d.largeur_cm + 2 * d.profondeur_soufflet_cm + rabat,
    h: d.hauteur_cm + fond
  })
};

/* ------------------------------------------------------------
   3 · Unités de « Quantité par emballage »
   La première de la liste est la valeur par défaut.
   ------------------------------------------------------------ */
const UNITES_QUANTITE = ['pièces', 'g', 'kg', 'mL', 'L', 'cm', 'm', 'm²'];
const UNITE_QUANTITE_DEFAUT = UNITES_QUANTITE[0];
